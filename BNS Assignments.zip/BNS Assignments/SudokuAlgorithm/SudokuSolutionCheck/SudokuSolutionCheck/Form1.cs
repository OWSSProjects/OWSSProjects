﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SudokuSolutionCheck
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public static bool IsValid(int[] values)
        {
            // bit field (set to zero => no values processed yet)
            int flag = 0;
            foreach (int value in values)
            {
                // value == 0 => reserved for still not filled cells, not to be processed
                if (value != 0)
                {
                    // prepares the bit mask left-shifting 1 of value positions
                    int bit = 1 << value;
                    // checks if the bit is already set, and if so the Sudoku is invalid
                    if ((flag & bit) != 0)
                        return false;
                    // otherwise sets the bit ("value seen")
                    flag |= bit;
                }
            }
            // if we didn't exit before, there are no problems with the given values
            return true;
        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Text|*.txt|All|*.*";
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.

            if (result == DialogResult.OK)
            {
                string file = openFileDialog1.FileName;
                int[] values = new int[9];

                try
                {
                    IEnumerable<string> lines = File.ReadLines(file);

                    int i = 0;
                    foreach (string s in lines)
                        if (!string.IsNullOrEmpty(s.Trim()))
                        {
                            int value = 0;
                            int.TryParse(s, out value);
                            if (value !=0)
                                values[i++] = int.Parse(s);
                        }

                    if (IsValid(values))
                        lblResult.Text = "Valid!";
                    else
                        lblResult.Text = "Not valid!";

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Exception occurred!");
                }
            }
        }
    }
}
